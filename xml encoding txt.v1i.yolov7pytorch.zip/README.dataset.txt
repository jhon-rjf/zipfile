# xml encoding txt > 2024-04-02 10:29pm
https://universe.roboflow.com/barcode-q28yc/xml-encoding-txt

Provided by a Roboflow user
License: CC BY 4.0

